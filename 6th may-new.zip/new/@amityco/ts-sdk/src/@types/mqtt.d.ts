declare module 'mqtt/dist/mqtt' {
  export * from 'mqtt';
}
