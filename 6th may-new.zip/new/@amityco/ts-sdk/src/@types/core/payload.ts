export {};

declare global {
  namespace Amity {
    type Payloads = {
      user: Amity.UserPayload;
      file: Amity.FilePayload;
      role: Amity.RolePayload;
      channel: Amity.ChannelPayload;
      subChannel: Amity.SubChannelPayload;
      channelUser: Amity.ChannelMembershipPayload;
      message: Amity.MessagePayload;
      community: Amity.CommunityPayload;
      category: Amity.CategoryPayload;
      communityUser: Amity.CommunityMembershipPayload;
      post: Amity.PostPayload;
      comment: Amity.CommentPayload;
      poll: Amity.PollPayload;
      stream: Amity.StreamPayload;
      reaction: Amity.ReactionPayload;
    };

    type UserPayload = {
      users: Amity.User[];
      files: Amity.File<'image'>[];
    };

    type FeedSettingPayload = {
      feedSettings: {
        contentSettings: Amity.ContentSetting[];
        feedType: Amity.ContentFeedType;
      }[];
    };

    // API-FIX: backend should return a payload like { files: Amity.File<T>[] }
    type CreateFilePayload<T extends Amity.FileType = any> = Amity.File<T>[];
    type FilePayload<T extends Amity.FileType = any> = Amity.File<T>;

    type RolePayload = {
      roles: Amity.Role[];
    };

    type ChannelPayload<T extends Amity.ChannelType = any> = {
      channels: Amity.RawChannel<T>[];
      channelUsers: Amity.RawMembership<'channel'>[];
    } & Amity.UserPayload;

    /**
     * Items that extend from `Amity.Channel`
     * - channels: `Amity.RawChannel` -> `Amity.Channel` (Added Marker Service related props)
     * - channelUsers: `Amity.RawMembership` -> `Amity.Membership` (Add user getter prop)
     */
    type ProcessedChannelPayload<T extends Amity.ChannelType = any> = Omit<
      ChannelPayload,
      'channels' | 'channelUsers'
    > & {
      channels: Amity.Channel<T>[];
      channelUsers: Amity.Membership<'channel'>[];
    };

    type ChannelMarkerPayload = {
      userEntityMarkers: Amity.ChannelMarker[];
      userMarkers: Amity.UserMarker[];
    };

    type SubChannelMarkerPayload = {
      userFeedMarkers: Amity.SubChannelMarker[];
      userEntityMarkers: Amity.ChannelMarker[];
      userMarkers: Amity.UserMarker[];
    };

    type MessageMarkerPayload = {
      contentMarkers: Amity.MessageMarker[];
      feedMarkers: Amity.FeedMarker[];
      userMarkers: Amity.UserMarker[];
    };

    type MarkReadPayload = {
      userMarkers: Amity.UserMarker[];
      userEntityMarkers: Amity.ChannelMarker[];
      userFeedMarkers: Amity.SubChannelMarker[];
      feedMarkers: Amity.MessageMarker[];
    };

    type MarkerSyncPayload = {
      userMarkers: Amity.UserMarker[];
      userEntityMarkers: Amity.ChannelMarker[];
      userFeedMarkers: Amity.SubChannelMarker[];
      feedMarkers: Amity.FeedMarker[];
    };

    type MarkAsReadPayload = {
      userMarkers: Amity.UserMarker[];
      userEntityMarkers: Amity.ChannelMarker[];
      userFeedMarkers: Amity.SubChannelMarker[];
      feedMarkers: Amity.FeedMarker[];
    };

    type MarkDeliveredPayload = {
      userMarkers: Amity.UserMarker[];
      userEntityMarkers: Amity.ChannelMarker[];
      userFeedMarkers: Amity.SubChannelMarker[];
      feedMarkers: Amity.FeedMarker[];
    };

    type ReadUserPayload = {
      contentMarkers: Amity.MessageMarker[];
      feedMarkers: Amity.FeedMarker[];
      userFeedMarker: Amity.SubChannelMarker[];
      publicUserIds: Amity.User['userId'][];
    };

    type DeliveredUserPayload = {
      contentMarkers: Amity.MessageMarker[];
      feedMarkers: Amity.FeedMarker[];
      userFeedMarker: Amity.SubChannelMarker[];
      publicUserIds: Amity.User['userId'][];
    };

    type StartReadingPayload = {
      userMarkers: Amity.UserMarker[];
      userEntityMarkers: Amity.ChannelMarker[];
      userFeedMarkers: Amity.SubChannelMarker[];
      feedMarkers: Amity.FeedMarker[];
    };

    type StopReadingPayload = {
      userMarkers: Amity.UserMarker[];
      userEntityMarkers: Amity.ChannelMarker[];
      userFeedMarkers: Amity.SubChannelMarker[];
      feedMarkers: Amity.FeedMarker[];
    };

    type MarkedMessagePayload = {
      contentMarkers: Amity.MessageMarker[];
      feedMarkers: Amity.FeedMarker[];
    };

    type SubChannelPayload = {
      messageFeeds: Amity.RawSubChannel[];
    };

    /**
     * Items that extend from `Amity.SubChannelPayload`
     * - messageFeeds: `Amity.RawSubChannel` -> `Amity.SubChannel` (Model Restructuring)
     */
    type ProcessedSubChannelPayload = {
      messageFeeds: Amity.SubChannel[];
    };

    type ChannelMembershipPayload = {
      channels: Amity.RawChannel[];
      channelUsers: Amity.RawMembership<'channel'>[];
    } & Amity.UserPayload;

    /**
     * Items that extend from `Amity.ChannelMembershipPayload`
     * - channels: `Amity.RawChannel` -> `Amity.Channel` (Added Marker Service related props)
     * - channelUsers: `Amity.RawMembership` -> `Amity.Membership` (Add user getter prop)
     */
    type ProcessedChannelMembershipPayload = Omit<
      ChannelMembershipPayload,
      'channels' | 'channelUsers'
    > & {
      channels: Amity.Channel[];
      channelUsers: Amity.Membership<'channel'>[];
    };

    /**
     * Items that extend from `Amity.MessagePayload`
     * - messages: `Amity.RawMessage` -> `Amity.Message` (Model Restructuring)
     */
    type ProcessedMessagePayload<T extends Amity.MessageContentType = any> = {
      messages: Amity.Message<T>[];
      users: Amity.User[];
      files: Amity.File[];
    };

    type MessagePayload<T extends Amity.MessageContentType = any> = Omit<
      ProcessedMessagePayload<T>,
      'messages'
    > & {
      messages: Amity.RawMessage<T>[];
    };

    type StreamPayload = {
      videoStreamings: Amity.Stream[];
      users: Amity.User[];
      files: Amity.File<'image'>[];
    };

    type CommunityPayload = {
      communities: Amity.RawCommunity[];
      communityUsers: Amity.RawMembership<'community'>[];
      categories: Amity.Category[];
      feeds: Amity.Feed[];
      users: Amity.User[];
      files: Amity.File[];
    };

    /**
     * Items that extend from `Amity.CommunityPayload`
     * - communities: `Amity.RawCommunity` -> `Amity.Community` (Added Marker Service related props)
     * - communityUsers: `Amity.RawMembership` -> `Amity.Membership` (Add user getter prop)
     */
    type ProcessedCommunityPayload = Omit<CommunityPayload, 'communities' | 'communityUsers'> & {
      communities: Amity.Community[];
      communityUsers: Amity.Membership<'community'>[];
    };

    type CategoryPayload = {
      categories: Amity.Category[];
      files: Amity.File[];
    };

    type CommunityMembershipPayload = {
      communities: Amity.RawCommunity[];
      communityUsers: Amity.RawMembership<'community'>[];
      categories: Amity.Category[];
      feeds: Amity.Feed[];
      users: Amity.User[];
      files: Amity.File[];
    };

    /**
     * Items that extend from `Amity.CommunityMembershipPayload`
     * - communities: `Amity.RawCommunity` -> `Amity.Community` (Added Marker Service related props)
     * - communityUsers: `Amity.RawMembership` -> `Amity.Membership` (Add user getter prop)
     */
    type ProcessedCommunityMembershipPayload = Omit<
      CommunityMembershipPayload,
      'communities' | 'communityUsers'
    > & {
      communities: Amity.Community[];
      communityUsers: Amity.Membership<'community'>[];
    };

    type PostPayload<T extends Amity.PostContentType = any> = {
      posts: Amity.Post<T>[];
      postChildren: Amity.Post[];
      communities: Amity.RawCommunity[];
      communityUsers: Amity.RawMembership<'community'>[];
      categories: Amity.Category[];
      comments: Amity.Comment[];
      feeds: Amity.Feed[];
      users: Amity.User[];
      files: Amity.File[];
    };

    /**
     * Items that extend from `Amity.PostPayload`
     * - communities: `Amity.RawCommunity` -> `Amity.Community` (Added Marker Service related props)
     * - communityUsers: `Amity.RawMembership` -> `Amity.Membership` (Add user getter prop)
     */
    type ProcessedPostPayload = Omit<PostPayload, 'communities' | 'communityUsers'> & {
      communities: Amity.Community[];
      communityUsers: Amity.Membership<'community'>[];
    };

    type CommentPayload<T extends Amity.CommentContentType = any> = {
      comments: Amity.Comment<T>[];
      commentChildren: Amity.Comment[];
      users: Amity.User[];
      files: Amity.File[];
    };

    type PollPayload = {
      users: Amity.User[];
      polls: Amity.Poll[];
    };

    type ReactionPayload = {
      reactions: Amity.ReactionQuery[];
      users: Amity.User[];
    };

    type GlobalFeedPayload = Amity.PostPayload;

    type FollowStatusPayload = {
      follows: Amity.FollowStatus[];
    };

    type FollowInfoMePayload = {
      followCounts: Amity.FollowCount[];
    };

    type FollowersPayload = Amity.FollowStatusPayload & UserPayload;

    type FollowInfoPayload = FollowInfoMePayload & Amity.FollowStatusPayload;

    type BlockedPayload = {
      follows: Amity.FollowStatusPayload['follows'];
      followCounts: Amity.FollowCount[];
    };

    type BlockedUserPayload = Amity.FollowStatusPayload[] &
      Amity.UserPayload &
      Amity.BlockedUserPaged;
  }
}
