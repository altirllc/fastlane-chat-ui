export {};

declare global {
  namespace Amity {
    /**
     * type map of "domain name -> ASC model"
     * @hidden
     */
    type Models = {
      user: Amity.User;
      file: Amity.File;
      role: Amity.Role;

      channel: Amity.Channel;
      subChannel: Amity.SubChannel;
      channelUsers: Amity.Membership<'channel'>;
      message: Amity.Message;

      channelMarker: Amity.ChannelMarker;
      subChannelMarker: Amity.SubChannelMarker;
      messageMarker: Amity.MessageMarker;
      feedMarker: Amity.FeedMarker;
      userMarker: Amity.UserMarker;

      community: Amity.Community;
      category: Amity.Category;
      communityUsers: Amity.Membership<'community'>;
      post: Amity.Post;
      comment: Amity.Comment;
      poll: Amity.Poll;
      reaction: Amity.Reaction;

      stream: Amity.Stream;

      follow: Amity.FollowStatus;
      followInfo: Amity.FollowInfo;
      followCount: Amity.FollowCount;

      feed: Amity.Feed;
    };

    type Model = ValueOf<Models>;
    type Domain = keyof Models;

    /**
     * Definition of the minimal set of properties necessary to identify
     * successfully a model.
     * @hidden
     */
    type Minimal = {
      user: Pick<Amity.User, 'userId'>;
      file: Pick<Amity.File, 'fileId'>;
      role: Pick<Amity.Role, 'roleId'>;

      channel: Pick<Amity.Channel, 'channelId'>;
      subChannel: Pick<Amity.SubChannel, 'subChannelId'>;
      channelUsers: Pick<Amity.Membership<'channel'>, 'channelId' | 'userId'>;
      message: Pick<Amity.Message, 'messageId'>;

      channelMarker: Pick<Amity.ChannelMarker, 'entityId' | 'userId'>;
      subChannelMarker: Pick<Amity.SubChannelMarker, 'feedId' | 'entityId' | 'userId'>;
      messageMarker: Pick<Amity.MessageMarker, 'feedId' | 'contentId' | 'creatorId'>;
      feedMarker: Pick<Amity.FeedMarker, 'feedId' | 'entityId'>;
      userMarker: Pick<Amity.UserMarker, 'userId'>;

      community: Pick<Amity.Community, 'communityId'>;
      category: Pick<Amity.Category, 'categoryId'>;
      communityUsers: Pick<Amity.Membership<'community'>, 'communityId' | 'userId'>;
      post: Pick<Amity.Post, 'postId'>;
      comment: Pick<Amity.Comment, 'commentId'>;
      poll: Pick<Amity.Poll, 'pollId'>;
      reaction: Pick<Amity.Reaction, 'reactionId'>;

      stream: Pick<Amity.Stream, 'streamId'>;

      follow: Pick<Amity.FollowStatus, 'from' | 'to'>;
      followInfo: Pick<Amity.FollowInfo, 'userId' | 'status'>;
      followCount: Pick<Amity.FollowInfo, 'userId' | 'followerCount'>;

      feed: Pick<Amity.Feed, 'targetId' | 'feedId'>;
    };
  }
}
