export {};

declare global {
  namespace Amity {
    type LiveObject<T extends any> = {
      data: T;
      error?: any;
      loading: boolean;
      origin?: 'local' | 'server' | 'event';
    };

    type LiveObjectCallback<T extends any> = Amity.Listener<LiveObject<T>>;

    type LiveCollection<T extends any> = LiveObject<T[]> & {
      onNextPage: () => void;
      hasNextPage: boolean;
    };

    type LiveCollectionCallback<T extends any> = Amity.Listener<LiveCollection<T>>;

    type LiveCollectionConfig = {
      policy?: Exclude<Amity.QueryPolicy, 'no_fetch'>;
    };

    type LiveCollectionParams<T extends any> = T & {
      limit?: number;
    };

    type LiveCollectionCache<T extends any, U extends any> = Pick<
      LiveCollection<T>,
      'data' | 'error' | 'loading'
    > & { params: U };
  }
}
