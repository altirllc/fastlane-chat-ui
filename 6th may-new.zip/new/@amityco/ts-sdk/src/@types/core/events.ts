/* eslint-disable camelcase */
import { IConnectPacket, IDisconnectPacket, IPublishPacket } from 'mqtt/dist/mqtt';

export {};

declare global {
  namespace Amity {
    type Listener<T = any> = (params: T) => any;

    type ObjectListener<T, K extends string[]> =
      | Listener<T>
      | ({
          onEvent?: (event: K[number], params: T) => void;
        } & {
          [P in K[number]]?: Listener<T>;
        });

    type Unsubscriber = () => void;

    type Subscriber<T = any> = (fn: Amity.Listener<T>) => Unsubscriber;

    type WsEvents = {
      disconnected: Amity.ErrorResponse | undefined;
      error: Amity.ErrorResponse | undefined;
      connect_error: Amity.ErrorResponse | undefined;
      reconnect_error: Amity.ErrorResponse | undefined;
      reconnect_failed: Amity.ErrorResponse | undefined;

      'video-streaming.didRecord': Amity.StreamPayload;
      'video-streaming.didStart': Amity.StreamPayload;
      'video-streaming.didStop': Amity.StreamPayload;
    };

    type MqttEvents = {
      connect: IConnectPacket;
      message: [topic: string, payload: Buffer, packet: IPublishPacket];
      disconnect: IDisconnectPacket;
      error: Error;
      close: Error;
      end: undefined;
      reconnect: undefined;
      'user.didGlobalBan': Amity.UserPayload;
    };

    type MqttChannelUserEvents = {
      'channel.joined': Amity.ChannelMembershipPayload;
      'channel.left': Amity.ChannelMembershipPayload;
      'channel.membersAdded': Amity.ChannelMembershipPayload;
      'channel.membersRemoved': Amity.ChannelMembershipPayload;
      'channel.banned': Amity.ChannelMembershipPayload;
      'channel.unbanned': Amity.ChannelMembershipPayload;
    };

    type MqttChannelEvents = {
      'channel.created': Amity.ChannelPayload;
      'channel.updated': Amity.ChannelPayload;
      'channel.deleted': Amity.ChannelPayload;
      'channel.setMuted': Amity.ChannelPayload;
    } & MqttChannelUserEvents;

    type MqttSubChannelEvents = {
      'message-feed.created': Amity.SubChannelPayload;
      'message-feed.updated': Amity.SubChannelPayload;
      'message-feed.deleted': Amity.SubChannelPayload;
    };

    type MqttMessageEvents = {
      'message.created': Amity.MessagePayload;
      'message.updated': Amity.MessagePayload;
      'message.deleted': Amity.MessagePayload;
      'message.flagged': Amity.MessagePayload;
      'message.unflagged': Amity.MessagePayload;
      'message.flagCleared': Amity.MessagePayload;
      'message.reactionAdded': Amity.MessagePayload;
      'message.reactionRemoved': Amity.MessagePayload;
    };

    type MqttCommunityUserEvents = {
      'community.joined': Amity.CommunityMembershipPayload;
      'community.left': Amity.CommunityMembershipPayload;
      'community.userAdded': Amity.CommunityMembershipPayload;
      'community.userRemoved': Amity.CommunityMembershipPayload;
      'community.userChanged': Amity.CommunityMembershipPayload;
      'community.userBanned': Amity.CommunityMembershipPayload;
      'community.userUnbanned': Amity.CommunityMembershipPayload;
      'community.roleAdded': Amity.CommunityMembershipPayload;
      'community.roleRemoved': Amity.CommunityMembershipPayload;
    };

    type MqttCommunityEvents = {
      'community.created': Amity.CommunityPayload;
      'community.updated': Amity.CommunityPayload;
      'community.deleted': Amity.CommunityPayload;
    } & MqttCommunityUserEvents;

    type MqttPostEvents = {
      'post.created': Amity.PostPayload;
      'post.updated': Amity.PostPayload;
      'post.deleted': Amity.PostPayload;
      'post.approved': Amity.PostPayload;
      'post.declined': Amity.PostPayload;
      'post.flagged': Amity.PostPayload;
      'post.unflagged': Amity.PostPayload;
      'post.addReaction': Amity.PostPayload & { reactor: Amity.Reaction };
      'post.removeReaction': Amity.PostPayload & { reactor: Amity.Reaction };
    };

    type MqttCommentEvents = {
      'comment.created': Amity.CommentPayload;
      'comment.updated': Amity.CommentPayload;
      'comment.deleted': Amity.CommentPayload;
      'comment.flagged': Amity.CommentPayload;
      'comment.unflagged': Amity.CommentPayload;
      'comment.addReaction': Amity.CommentPayload & { reactor: Amity.Reaction };
      'comment.removeReaction': Amity.CommentPayload & { reactor: Amity.Reaction };
    };

    type MqttUserEvents = {
      'user.fetched': Amity.UserPayload;
      'user.updated': Amity.UserPayload;
      'user.deleted': Amity.UserPayload; // received from network topic
      'user.flagged': Amity.UserPayload;
      'user.unflagged': Amity.UserPayload;
      'user.flagCleared': Amity.UserPayload;
    };

    type MqttFollowEvents = {
      'follow.created': Amity.FollowersPayload | Amity.FollowStatusPayload;
      'follow.requested': Amity.FollowersPayload | Amity.FollowStatusPayload;
      'follow.accepted': Amity.FollowersPayload | Amity.FollowStatusPayload;
      'follow.unfollowed': Amity.FollowersPayload | Amity.FollowStatusPayload;
      'follow.requestCanceled': Amity.FollowersPayload | Amity.FollowStatusPayload;
      'follow.requestDeclined': Amity.FollowersPayload | Amity.FollowStatusPayload;
      'follow.followerDeleted': Amity.FollowersPayload | Amity.FollowStatusPayload;
    };

    type MqttMarkerEvents = {
      'marker.marked-message': Amity.MarkedMessagePayload;
    };

    type MqttRTE = MqttChannelEvents &
      MqttSubChannelEvents &
      MqttMessageEvents &
      MqttCommunityEvents &
      MqttPostEvents &
      MqttCommentEvents &
      MqttUserEvents &
      MqttFollowEvents &
      MqttMarkerEvents;

    type LocalEvents = {
      'local.channel.updated': MakeRequired<Amity.ProcessedChannelPayload, 'channels'>;
      'local.message.created': MakeRequired<Amity.ProcessedMessagePayload, 'messages'>;
      'local.message.updated': MakeRequired<Amity.ProcessedMessagePayload, 'messages'>;
      'local.message.deleted': MakeRequired<Amity.ProcessedMessagePayload, 'messages'>;
      'local.message.fetched': MakeRequired<Amity.ProcessedMessagePayload, 'messages'>;
      'local.message-feed.updated': MakeRequired<Amity.ProcessedSubChannelPayload, 'messageFeeds'>;
      'local.message-feed.fetched': MakeRequired<Amity.ProcessedSubChannelPayload, 'messageFeeds'>;
      'local.message-feed.deleted': MakeRequired<Amity.ProcessedSubChannelPayload, 'messageFeeds'>;
      'poll.updated': MakeRequired<Amity.PollPayload, 'polls'>;
      'poll.deleted': MakeRequired<Amity.PollPayload, 'polls'>;
      'local.feedMarker.fetched': { feedMarkers: Amity.FeedMarker[] };
      'local.channelMarker.fetched': MakeRequired<Amity.ChannelMarkerPayload, 'userEntityMarkers'>;
      'local.subChannelMarker.fetched': MakeRequired<
        Amity.SubChannelMarkerPayload,
        'userFeedMarkers'
      >;
      'local.subChannelMarker.updated': MakeRequired<
        Amity.SubChannelMarkerPayload,
        'userFeedMarkers'
      >;
      'local.messageMarker.fetched': MakeRequired<Amity.MessageMarkerPayload, 'contentMarkers'>;
      'local.userMarker.fetched': { userMarkers: Amity.UserMarker[] };

      sessionStateChange: Amity.SessionStates;
      // used by accessTokenExpiryWatcher
      tokenExpired: Amity.SessionStates.TOKEN_EXPIRED;
      tokenTerminated: Amity.SessionStates.TERMINATED;
    };

    type Events = WsEvents & MqttEvents & MqttRTE & LocalEvents;
  }
}
