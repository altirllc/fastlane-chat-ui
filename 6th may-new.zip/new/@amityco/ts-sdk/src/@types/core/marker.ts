export {};

declare global {
  namespace Amity {
    type ChannelMarker = {
      entityId: Amity.RawChannel['channelId'];
      userId: Amity.User['userId'];
      unreadCount: number;
      isDeleted: boolean;
    } & Amity.Timestamps;

    type SubChannelMarker = {
      feedId: Amity.RawSubChannel['messageFeedId'];
      entityId: Amity.RawChannel['channelId'];
      userId: Amity.User['userId'];
      readToSegment: number;
      deliveredToSegment: number;
      unreadCount: number;
    } & Amity.Timestamps;

    type MessageMarker = {
      feedId: Amity.RawSubChannel['messageFeedId'];
      contentId: Amity.RawMessage['messageId'];
      creatorId: Amity.User['userId'];
      readCount: number;
      deliveredCount: number;
    } & Amity.Timestamps;

    type FeedMarker = {
      feedId: Amity.RawSubChannel['messageFeedId'];
      entityId: Amity.RawChannel['channelId'];
      lastSegment: number;
      isDeleted: boolean;
    } & Amity.Timestamps;

    type UserMarker = {
      userId: Amity.User['userId'];
      unreadCount: number;
    } & Amity.SyncAt &
      Amity.Timestamps;
  }
}
