export {};

declare global {
  namespace Amity {
    type UserActionType =
      | 'onFetch'
      | 'onUpdate'
      | 'onDelete'
      | 'onFlagged'
      | 'onUnflagged'
      | 'onFlagCleared';

    type User = {
      _id: string;
      userId: string;
      displayName?: string;
      avatarFileId?: Amity.File<'image'>['fileId'];
      avatarCustomUrl?: string;
      description?: string;
    } & Amity.Metadata &
      Amity.Taggable &
      Amity.Flaggable &
      Amity.Accredited &
      Amity.Timestamps &
      Amity.SoftDelete &
      Amity.Subscribable;

    type QueryUsers = {
      displayName?: Amity.User['displayName'];
      filter?: 'all' | 'flagged';
      sortBy?: 'displayName' | 'firstCreated' | 'lastCreated';
      page?: Amity.Page;
    };

    type UserLiveCollection = Amity.LiveCollectionParams<Omit<QueryUsers, 'page'>>;

    type UserLiveCollectionCache = Amity.LiveCollectionCache<
      Amity.User['userId'],
      Pick<QueryUsers, 'page'>
    >;
  }
}
