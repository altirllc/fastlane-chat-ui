import { AxiosInstance } from 'axios';
import { Emitter } from 'mitt';

declare global {
  namespace Amity {
    type Logger = (topic: string, ...args: any[]) => void;

    const enum TokenTerminationReason {
      GLOBAL_BAN = 'globalBan',
      USER_DELETED = 'userDeleted',
      UNAUTHORIZED = 'unauthorized',
    }

    const enum SessionStates {
      NOT_LOGGED_IN = 'notLoggedIn',

      ESTABLISHING = 'establishing',
      ESTABLISHED = 'established',

      TOKEN_EXPIRED = 'tokenExpired',
      /*
       * Terminated is slightly different from NOT_LOGGED_IN:
       *
       * After established, upon receiving the termination code, the SDK will move to terminated.
       * Unlike tokenExpired that users can regain SDK usability by giving an auth token.
       * This state represents unrecoverable failures. The app must manually re-login with a valid user.
       *
       * For more details, please check tech spec:
       * https://ekoapp.atlassian.net/wiki/spaces/UP/pages/2082537485/ASC+Core+-+Session+Management+3.0#terminated
       */
      TERMINATED = 'terminated',
    }

    type Client = {
      version: string;

      log: Logger;
      http: AxiosInstance;
      mqtt: Amity.MqttClient;
      ws: SocketIOClient.Socket;
      emitter: Emitter<Amity.Events>;

      sessionState: Amity.SessionStates;
      sessionHandler?: Amity.SessionHandler;

      cache?: Amity.Cache;

      apiKey?: string;
      userId?: string;

      token?: Omit<Amity.Tokens, 'refreshToken'>;

      use: () => void;

      accessTokenExpiryWatcher: (
        expiresAt: Amity.Tokens['expiresAt'],
        issuedAt: Amity.Tokens['issuedAt'],
        sessionHandler: Amity.SessionHandler,
      ) => Amity.Unsubscriber;

      getFeedSettings: () => Promise<Amity.FeedSettings>;
    };

    type Device = {
      deviceId: string;
      deviceInfo: {
        kind: 'node' | 'web';
        model?: string;
        sdkVersion: string;
      };
    };

    type Tokens = {
      accessToken: string;
      refreshToken: string;
      // issuedAt, expiresAt is in iso Date format
      issuedAt: string;
      expiresAt: string;
    };

    type AccessTokenRenewal = {
      renew: () => void;
      renewWithAuthToken: (authToken: string) => void;
      unableToRetrieveAuthToken: () => void;
    };

    interface SessionHandler {
      sessionWillRenewAccessToken(renewal: AccessTokenRenewal): void;
    }

    type ChatSettings = {
      enabled: boolean;
      mention: {
        isAllowMentionedChannelEnabled: boolean;
      };
    };

    type FeedSettings = {
      [name in Amity.ContentFeedType]?: Amity.ContentSetting[];
    };

    type SocialSettings = {
      enabled: boolean;
      isAllowEditPostWhenReviewingEnabled: boolean;
      isFollowWithRequestEnabled: boolean;
      globalFeed: {
        showCommunityPost: boolean;
        showEveryonePost: boolean;
        showFollowingPost: boolean;
        showMyPost: boolean;
        showOnlyMyFeed: boolean;
      };
      userPrivacySetting: 'public' | 'private ';
    };

    type ConnectClientParams = {
      userId: Amity.User['userId'];
      displayName?: Amity.User['displayName'];
      authToken?: string;
      deviceId?: Amity.Device['deviceId'];
    };

    type ConnectClientConfig = {
      disableRTE: boolean;
    };

    type ActiveUser = Pick<Amity.User, '_id' | 'userId' | 'path' | 'displayName'>;
  }
}
