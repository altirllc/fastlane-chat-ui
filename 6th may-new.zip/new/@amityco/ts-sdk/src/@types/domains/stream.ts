export {};

declare global {
  namespace Amity {
    const enum StreamStatus {
      IDLE = 'idle',
      LIVE = 'live',
      ENDED = 'ended',
      RECORDED = 'recorded',
    }

    const enum StreamResolution {
      SD = 'SD',
      HD = 'HD',
      FHD = 'FHD',
    }

    type MultiFormat<T> = {
      flv?: T;
      mp4?: T;
      m3u8?: T;
    };

    type StreamPlatform = {
      name: string;
      version: string;
    };

    type StreamEndpoint = {
      url: string;
      components: {
        origin: string;
        appName: string;
        streamName: string;
        query: string;
      };
    };

    type StreamRecording = {
      url: string;
      duration: number;
      startTime: number;
      stopTime: number;
    };

    type Stream = {
      streamId: string;
      title: string;
      thumbnailFileId?: Amity.File<'image'>['fileId'];
      description?: string;
      status: StreamStatus;
      platform: StreamPlatform;

      isLive?: boolean;
      endedAt: Amity.timestamp;
      startedAt: Amity.timestamp;
      userId: Amity.User['userId'];
      resolution: StreamResolution;

      streamerUrl: StreamEndpoint;
      watcherUrl: MultiFormat<StreamEndpoint>;
      recordings: MultiFormat<StreamRecording>[];
    } & Amity.Metadata &
      Amity.Timestamps &
      Amity.SoftDelete;
  }
}
