export {};

declare global {
  namespace Amity {
    type FollowActionType =
      | 'onRequested'
      | 'onAccepted'
      | 'onDeclined'
      | 'onCanceled'
      | 'onFollowed'
      | 'onUnfollowed'
      | 'onDeleted';

    type FollowStatusType = 'all' | 'pending' | 'accepted' | 'blocked' | 'none';

    type FollowStatus = {
      from: Amity.User['userId'];
      to: Amity.User['userId'];
      status: Exclude<FollowStatusType, 'all'>;
    } & Amity.CreatedAt &
      Amity.UpdatedAt;

    type FollowCount = {
      userId: Amity.User['userId'];
      followerCount: number;
      followingCount: number;
      pendingCount: number;
    };

    type FollowInfo = {
      status?: FollowStatus['status'];
    } & FollowCount;

    type QueryFollowers = {
      userId: Amity.User['userId'];
      status?: Exclude<Amity.FollowStatusType, 'none'>;
      page?: Amity.PageRaw;
    };

    type FollowerLiveCollection = Amity.LiveCollectionParams<Omit<QueryFollowers, 'page'>>;

    type FollowerLiveCollectionCache = Amity.LiveCollectionCache<
      Amity.FollowInfo['userId'],
      Pick<QueryFollowers, 'page'>
    >;

    type QueryFollowings = QueryFollowers;

    type FollowingLiveCollection = FollowerLiveCollection;

    type FollowingLiveCollectionCache = FollowerLiveCollectionCache;
  }
}
