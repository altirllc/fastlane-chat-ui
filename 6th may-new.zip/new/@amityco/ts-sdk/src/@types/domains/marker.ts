export {};

declare global {
  namespace Amity {
    const enum MarkerSyncEvent {
      START_SYNCING = 'start syncing',
      HAS_MORE = 'has_more',
      NEW_MESSAGE = 'new message',
      RESUME = 'resume',
      SUB_CHANNEL_CREATED = 'subchannel is created',
      SUBCHANNEL_IS_DELETED = 'subchannel is deleted',
      FORCE_SYNC = 'force sync',
    }
  }
}
