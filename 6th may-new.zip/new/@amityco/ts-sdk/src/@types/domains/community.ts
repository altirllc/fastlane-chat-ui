export const CommunityPostSettings = Object.freeze({
  ONLY_ADMIN_CAN_POST: 'ONLY_ADMIN_CAN_POST',
  ADMIN_REVIEW_POST_REQUIRED: 'ADMIN_REVIEW_POST_REQUIRED',
  ANYONE_CAN_POST: 'ANYONE_CAN_POST',
});

export const CommunityPostSettingMaps = Object.freeze({
  ONLY_ADMIN_CAN_POST: {
    needApprovalOnPostCreation: false,
    onlyAdminCanPost: true,
  },
  ADMIN_REVIEW_POST_REQUIRED: {
    needApprovalOnPostCreation: true,
    onlyAdminCanPost: false,
  },
  ANYONE_CAN_POST: {
    needApprovalOnPostCreation: false,
    onlyAdminCanPost: false,
  },
});

export const DefaultCommunityPostSetting = 'ONLY_ADMIN_CAN_POST';

declare global {
  namespace Amity {
    type CommunityActionType =
      | 'onCreate'
      | 'onUpdate'
      | 'onDelete'
      | 'onJoin'
      | 'onLeft'
      | 'onMemberCountChanged';

    type CommunityMemberActionType =
      | 'onJoin'
      | 'onLeft'
      | 'onBan'
      | 'onUnban'
      | 'onMemberCountChanged';

    type RawCommunity = {
      communityId: string;

      displayName: string;
      avatarFileId?: File<'image'>['fileId'];
      description?: string;

      channelId: Amity.Channel['channelId'];
      userId: Amity.User['userId'];

      isOfficial?: boolean;
      isPublic?: boolean;
      isJoined?: boolean;
      onlyAdminCanPost?: boolean;
      needApprovalOnPostCreation?: boolean;

      postsCount: number;
      membersCount: number;

      categoryIds: Amity.Category['categoryId'][];

      hasFlaggedComment: boolean;
      hasFlaggedPost: boolean;
    } & Amity.Taggable &
      Amity.Metadata &
      Amity.Timestamps &
      Amity.SoftDelete &
      Amity.Subscribable;

    type Community = Omit<Amity.RawCommunity, 'onlyAdminCanPost' | 'needApprovalOnPostCreation'> & {
      postSetting?: ValueOf<typeof CommunityPostSettings>;
    };

    type QueryCommunities = {
      displayName?: string;
      membership?: 'all' | 'member' | 'notMember';
      categoryId?: Amity.Category['categoryId'];
      includeDeleted?: boolean;
      tags?: Amity.Taggable['tags'];
      sortBy?: 'displayName' | 'firstCreated' | 'lastCreated';
      page?: Amity.Page;
    };

    type CommunityLiveCollection = Amity.LiveCollectionParams<Omit<QueryCommunities, 'page'>>;

    type CommunityLiveCollectionCache = Amity.LiveCollectionCache<
      Amity.Community['communityId'],
      Pick<QueryCommunities, 'page'>
    >;

    type QueryCommunityMembers = {
      communityId: string;
      membership?: ('banned' | 'member')[];
      roles?: string[];
      sortBy?: 'firstCreated' | 'lastCreated';
      search?: Amity.User['displayName'] | Amity.User['userId'];
      page?: Amity.Page;
    };

    type CommunityMemberLiveCollection = Amity.LiveCollectionParams<
      Omit<QueryCommunityMembers, 'page'>
    >;

    type CommunityMemberLiveCollectionCache = Amity.LiveCollectionCache<
      Amity.Membership<'community'>['userId'],
      Pick<QueryCommunityMembers, 'page'>
    >;
  }
}
