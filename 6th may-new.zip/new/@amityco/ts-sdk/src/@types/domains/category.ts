export {};

declare global {
  namespace Amity {
    type Category = {
      categoryId: string;
      name: string;
      avatarFileId?: Amity.File<'image'>['fileId'];
    } & Amity.Metadata &
      Amity.Timestamps &
      Amity.SoftDelete;

    type QueryCategories = {
      includeDeleted?: boolean;
      sortBy?: 'name' | 'firstCreated' | 'lastCreated';
      page?: Amity.Page;
    };

    type CategoryLiveCollection = Amity.LiveCollectionParams<Omit<QueryCategories, 'page'>>;

    type CategoryLiveCollectionCache = Amity.LiveCollectionCache<
      Amity.Category['categoryId'],
      Pick<QueryCategories, 'page'>
    >;
  }
}
