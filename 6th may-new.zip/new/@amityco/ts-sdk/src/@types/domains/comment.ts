export {};

declare global {
  namespace Amity {
    type CommentContentType = 'text';
    type CommentReferenceType = 'content' | 'post';

    type CommentActionType =
      | 'onFetch'
      | 'onCreate'
      | 'onUpdate'
      | 'onDelete'
      | 'onFlagged'
      | 'onUnflagged'
      | 'onReactionAdded'
      | 'onReactionRemoved';

    type Comment<T extends CommentContentType = any> = {
      commentId: string;
      userId: string;
      parentId?: Comment['commentId'];
      rootId: Comment['commentId'];
      childrenNumber: number;
      children: Comment['commentId'][];
      segmentNumber: number;
      editedAt: Amity.timestamp;
      attachments?: Amity.Attachment[];
    } & Amity.Relationship<CommentReferenceType> &
      Amity.Content<T> &
      Amity.Metadata &
      Amity.Flaggable &
      Amity.Reactable &
      Amity.Timestamps &
      Amity.SoftDelete &
      Amity.Subscribable &
      Amity.Mentionable<'user'>;

    type QueryComments = {
      referenceType: Amity.Comment['referenceType'];
      referenceId: Amity.Comment['referenceId'];
      sortBy?: 'lastCreated' | 'firstCreated' | 'lastUpdated' | 'firstUpdated';
      parentId?: Amity.Comment['commentId'] | null;
      hasFlag?: boolean;
      includeDeleted?: boolean;
      page?: Amity.Page;
      dataTypes?: {
        values: ('image' | 'text')[];
        // matchType is a query format that you can set to any to query any type of comment
        // or exact to get a comment with exactly type that defined in dataTypes
        matchType: 'any' | 'exact';
      };
    };

    type CommentLiveCollection = Amity.LiveCollectionParams<
      Omit<QueryComments, 'sortBy' | 'page'> & {
        sortBy?: 'lastCreated' | 'firstCreated';
      }
    >;

    type CommentLiveCollectionCache = Amity.LiveCollectionCache<
      Amity.Comment['commentId'],
      Pick<QueryComments, 'page'>
    >;
  }
}
