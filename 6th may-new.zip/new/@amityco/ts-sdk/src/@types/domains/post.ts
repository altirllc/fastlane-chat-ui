export const PostContentType = Object.freeze({
  TEXT: 'text',
  IMAGE: 'image',
  FILE: 'file',
  VIDEO: 'video',
  LIVESTREAM: 'liveStream',
  POLL: 'poll',
  CUSTOM: 'custom',
});

declare global {
  namespace Amity {
    // bad hack until we get proper feed objects in backend
    type PostTargetType = Amity.Feed['targetType'] | 'content';

    type PostContentType = ValueOf<typeof PostContentType>;

    type PostActionType =
      | 'onFetch'
      | 'onCreate'
      | 'onUpdate'
      | 'onDelete'
      | 'onApproved'
      | 'onDeclined'
      | 'onFlagged'
      | 'onUnflagged'
      | 'onReactionAdded'
      | 'onReactionRemoved';

    type Post<T extends PostContentType = any> = {
      postId: string;
      postedUserId: Amity.User['userId']; // API-FIX: it should be "userId"
      parentId: Post['postId'];
      targetType: PostTargetType;
      targetId: string;
      feedId: Amity.Feed['feedId'];
      children: Amity.Post['postId'][];
      comments: Amity.Comment['commentId'][];
      commentsCount: number; // API-FIX: backend doesnt follow its own convention
      hasFlaggedChildren: false;
      hasFlaggedComment: false;
      editedAt: Amity.timestamp;
    } & Amity.Content<T> &
      Amity.Metadata &
      Amity.Flaggable &
      Amity.Reactable &
      Amity.Taggable &
      Amity.Timestamps &
      Amity.SoftDelete &
      Amity.Subscribable &
      Amity.Mentionable<'user'>;

    type QueryPosts = {
      targetId: string;
      targetType: Amity.Post['targetType'];
      sortBy?: 'lastCreated' | 'firstCreated' | 'lastUpdated' | 'firstUpdated';
      dataTypes?: Exclude<Amity.PostContentType, 'text'>[];
      includeDeleted?: boolean;
      hasFlag?: boolean;
      feedType?: 'reviewing' | 'published';
      tags?: Amity.Taggable['tags'];
      matchingOnlyParentPost?: boolean;
      page?: Amity.PageRaw;
    };

    // Omit sortBy explained in asc-3398
    type PostLiveCollection = Amity.LiveCollectionParams<
      Omit<QueryPosts, 'sortBy' | 'page'> & {
        sortBy?: 'lastCreated' | 'firstCreated';
      }
    >;

    type PostLiveCollectionCache = Amity.LiveCollectionCache<
      Amity.Post['postId'],
      Pick<QueryPosts, 'page'>
    >;
  }
}
