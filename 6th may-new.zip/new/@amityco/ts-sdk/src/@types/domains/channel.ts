export {};

declare global {
  namespace Amity {
    type ChannelType = 'broadcast' | 'conversation' | 'community' | 'live';

    type ChannelMemberActionType =
      | 'onJoin'
      | 'onLeft'
      | 'onMemberRead'
      | 'onMemberAdded'
      | 'onMemberRemoved'
      | 'onChannelMemberBanned'
      | 'onChannelMemberUnbanned';

    type ChannelActionType =
      | 'onFetch'
      | 'onCreate'
      | 'onUpdate'
      | 'onDelete'
      | 'onJoin'
      | 'onLeft'
      | 'onMute'
      | 'onMemberAdded'
      | 'onMemberRemoved';

    type RawChannel<T extends ChannelType = any> = {
      _id: string;
      channelId: string;
      displayName?: string;
      avatarFileId?: Amity.File<'image'>['fileId'];
      type: T;

      isDistinct?: boolean;

      isMuted?: boolean;
      muteTimeout?: string;

      isRateLimited?: boolean;
      rateLimit?: number;
      rateLimitWindow?: number;
      rateLimitTimeout?: number;

      messageAutoDeleteEnabled?: boolean;
      autoDeleteMessageByFlagLimit?: number;

      memberCount?: number;
      messageCount: number; // TODO remove from public interface
      moderatorMemberCount?: number;

      lastActivity: Amity.timestamp;
    } & Amity.Metadata &
      Amity.Taggable &
      Amity.Timestamps &
      Amity.SoftDelete &
      Amity.Subscribable;

    type Channel<T extends ChannelType = any> = RawChannel<T> & {
      defaultSubChannelId: string;
      isUnreadCountSupport: boolean;
      unreadCount: number;
    };

    type QueryChannels = {
      displayName?: string;
      membership?: 'all' | 'member' | 'notMember';
      sortBy?: 'displayName' | 'firstCreated' | 'lastCreated' | 'lastActivity';
      types?: Amity.ChannelType[];
      isDeleted?: Amity.Channel['isDeleted'];
      tags?: Amity.Taggable['tags'];
      excludeTags?: Amity.Taggable['tags'];
      page?: Amity.Page;
    };

    type ChannelLiveCollection = Amity.LiveCollectionParams<Omit<QueryChannels, 'page'>>;

    type ChannelLiveCollectionCache = Amity.LiveCollectionCache<
      Amity.Channel['channelId'],
      Pick<QueryChannels, 'page'>
    >;

    type QueryChannelMembers = {
      channelId: Amity.Channel['channelId'];
      memberships?: Array<Exclude<Amity.Membership<'channel'>['membership'], 'none'> | 'muted'>;
      roles?: string[];
      sortBy?: 'firstCreated' | 'lastCreated';
      search?: string;
      page?: Amity.Page;
    };

    type ChannelMembersLiveCollection = Amity.LiveCollectionParams<
      Omit<QueryChannelMembers, 'page'>
    >;

    type ChannelMembersLiveCollectionCache = Amity.LiveCollectionCache<
      Amity.Membership<'channel'>['userId'],
      Pick<QueryChannelMembers, 'page'>
    >;
  }
}
