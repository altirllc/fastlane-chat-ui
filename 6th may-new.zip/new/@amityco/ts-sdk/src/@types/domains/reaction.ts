export {};

declare global {
  namespace Amity {
    type ReactableType = 'message' | 'post' | 'comment';

    type ReactionActionType = 'onAdded' | 'onRemoved';

    type Reactor = {
      reactionId: string;
      reactionName: string;
      userId: Amity.User['userId'];
    } & Amity.CreatedAt;

    type Reaction = Amity.Reactor & Amity.Relationship<ReactableType>;

    type Reactable = {
      reactionsCount: number;
      reactions: Record<string, number>;
      myReactions?: string[];

      latestReaction?: Amity.Reaction & {
        eventName: 'add' | 'remove';
        userDisplayName: string;
      };
    };

    type ReactionQuery = {
      reactors: Reactor[];
    } & Amity.Relationship<ReactableType>;

    type QueryReactions = {
      referenceId: Amity.Reaction['referenceId'];
      referenceType: Amity.Reaction['referenceType'];
      reactionName?: Amity.Reaction['reactionName'];
      page?: Amity.Page<string>;
    };

    type ReactionLiveCollection = Amity.LiveCollectionParams<Omit<QueryReactions, 'page'>>;

    type ReactionLiveCollectionCache = Amity.LiveCollectionCache<
      Amity.Reactor['reactionId'],
      Pick<QueryReactions, 'page'>
    >;
  }
}
