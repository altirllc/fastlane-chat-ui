export {};

declare global {
  namespace Amity {
    type GroupType = 'channel' | 'community';

    type Group = {
      membersCount: number;
    };

    type Member<T extends GroupType> = {
      userId: Amity.User['userId'];
    } & (T extends 'channel'
      ? {
          channelId: Amity.Channel['channelId'];
          membership: 'member' | 'none' | 'banned';
          readToSegment: number;
          lastMentionedSegment: number;
        }
      : T extends 'community'
      ? {
          communityId: Amity.Community['communityId'];
          communityMembership: 'member' | 'none' | 'banned';
        }
      : never) &
      Amity.Timestamps;

    type MemberWithUser<T extends GroupType> = Member<T> & { user: Amity.User | undefined };

    type RawMembership<T extends GroupType, WithUser = false> = {
      isBanned: boolean;
      isMuted: boolean;
      muteTimeout: string;
      lastActivity: Amity.timestamp;
    } & (WithUser extends true ? MemberWithUser<T> : Member<T>) &
      Amity.Accredited;

    type Membership<T extends Amity.GroupType> = Amity.RawMembership<T, true>;
  }
}
