import { getActiveClient } from '~/client/api';
import {
  LIVE_OBJECT_ENABLE_CACHE_MESSAGE,
  UNSYNCED_OBJECT_CACHED_AT_MESSAGE,
  UNSYNCED_OBJECT_CACHED_AT_VALUE,
} from '~/utils/constants';
import { hasUpdates } from '~/core/model';
import { createQuery, runQuery } from '~/core/query';
import { ASCApiError } from '~/core/errors';

export const liveObject = <
  T extends Amity.Models[Amity.Domain],
  K extends keyof T,
  CallbackData extends any = any,
>(
  id: T[K],
  callback: Amity.LiveObjectCallback<CallbackData>,
  key: K,
  fetcher: (id: T[K]) => Promise<Amity.Cached<T>>,
  eventHandlers: Array<(callback: Amity.Listener<T>) => Amity.Unsubscriber>,
  callbackDataSelector: (data: T) => CallbackData = data => <CallbackData>data,
  callbackFilter?: (currentModel: T, previousModel: T) => boolean,
): Amity.Unsubscriber => {
  const { cache } = getActiveClient();

  if (!cache) {
    console.log(LIVE_OBJECT_ENABLE_CACHE_MESSAGE);
  }

  let model: T;
  let isUnsyncedModel = false; // for messages
  const disposers: Amity.Unsubscriber[] = [];

  const dispatcher = (data: Amity.LiveObject<T>) => {
    const { data: newModel, ...rest } = data;

    if (!callbackFilter || callbackFilter(newModel, model)) {
      callback({ data: callbackDataSelector(newModel), ...rest });
    }

    model = newModel;
  };

  const realtimeRouter = (eventModel: T) => {
    if (id !== eventModel[key]) {
      return;
    }

    if (model && !hasUpdates(model, eventModel)) {
      return;
    }

    dispatcher({ loading: false, data: eventModel, origin: 'event' });
  };

  const onFetch = () => {
    // @ts-ignore
    const query = createQuery(fetcher, id, true);

    runQuery(query, ({ error, data, loading, origin, cachedAt }) => {
      if (cachedAt === UNSYNCED_OBJECT_CACHED_AT_VALUE) {
        dispatcher({
          // @ts-ignore
          data,
          origin,
          loading: false,
          error: new ASCApiError(
            UNSYNCED_OBJECT_CACHED_AT_MESSAGE,
            Amity.ClientError.DISALOOW_UNSYNCED_OBJECT,
            Amity.ErrorLevel.ERROR,
          ),
        });

        isUnsyncedModel = true;
        disposers.forEach(fn => fn());
      } else if (!isUnsyncedModel) {
        // @ts-ignore
        dispatcher({ loading, data, origin, error });
      }

      if (error) {
        disposers.forEach(fn => fn());
      }
    });
  };

  disposers.push(...eventHandlers.map(fn => fn(realtimeRouter)));

  onFetch();

  return () => {
    disposers.forEach(fn => fn());
  };
};
