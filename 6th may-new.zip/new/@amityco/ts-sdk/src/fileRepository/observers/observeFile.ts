import { createQuery, runQuery } from '~/core/query/query';

import { getActiveClient } from '~/client/api';

import { getFile } from '../api';

/**
 * ```js
 * import { observeFile } from '@amityco/ts-sdk'
 *
 * let file = {}
 * const dispose = observeFile(fileId, updated => file = updated)
 * ```
 *
 * Observe all mutation on a given {@link Amity.File}
 *
 * @param fileId the ID of the file to observe
 * @param callback the function to call when new data are available
 * @returns An {@link Amity.Unsubscriber} function to run when willing to stop observing the file
 *
 * @category File Observer
 */
export const observeFile = <Events extends ['onFetch']>(
  fileId: string,
  callback: Amity.ObjectListener<Amity.Snapshot<Amity.File>, Events>,
): Amity.Unsubscriber => {
  const { log } = getActiveClient();

  const timestamp = Date.now();
  log(`observeFile(tmpid: ${timestamp}) > listen`);

  // wrapper function to make sure
  const router = (result: Amity.Snapshot<Amity.File>, action: Events[number]) => {
    // filter function
    if (result.data?.fileId !== fileId) return;

    if (callback instanceof Function) return callback(result);

    if (action !== 'onFetch') callback.onEvent?.(action, result);

    callback[action]?.(result);
  };

  runQuery(createQuery(getFile, fileId), result => result.data && router(result, 'onFetch'));

  return () => {
    log(`observeFile(tmpid: ${timestamp}) > dispose`);
  };
};
