import { getActiveClient } from '~/client/api/activeClient';

import { toToken, toPage } from '~/core/query';

import { pullFromCache, pushToCache } from '~/cache/api';
import { ingestInCache } from '~/cache/api/ingestInCache';
import { getResolver } from '~/core/model';

import { inferIsDeleted } from '~/utils/inferIsDeleted';

/**
 * ```js
 * import { queryCategories } from '@amityco/ts-sdk'
 * const { data: categories, prevPage, nextPage } = await queryCategories()
 * ```
 *
 * Queries a paginable list of {@link Amity.Category} objects
 *
 * @param query The query parameters
 * @returns A page of {@link Amity.Category} objects
 *
 * @category Category API
 * @async
 * */
export const queryCategories = async (
  query?: Amity.QueryCategories,
): Promise<Amity.Cached<Amity.Paged<Amity.Category, Amity.Page>>> => {
  const client = getActiveClient();
  client.log('category/queryCategories', query);

  const { page = { limit: 10 }, includeDeleted, ...params } = query ?? {};

  const { data } = await client.http.get<Amity.CategoryPayload & Amity.Pagination>(
    `/api/v3/community-categories`,
    {
      params: {
        ...params,
        isDeleted: inferIsDeleted(includeDeleted),
        options: {
          token: toToken(page, 'skiplimit'),
        },
      },
    },
  );

  const { paging, ...payload } = data;
  const { categories } = payload;

  const cachedAt = client.cache && Date.now();

  if (client.cache) {
    ingestInCache(payload as Amity.CategoryPayload, { cachedAt });

    const cacheKey = [
      'category',
      'query',
      { ...params, options: { ...page } } as Amity.Serializable,
    ];
    pushToCache(cacheKey, { categories: categories.map(getResolver('category')), paging });
  }

  const nextPage = toPage(paging.next);
  const prevPage = toPage(paging.previous);

  return { data: categories, cachedAt, prevPage, nextPage };
};

/**
 * ```js
 * import { queryCategories } from '@amityco/ts-sdk'
 * const { data: categories, prevPage, nextPage } = queryCategories.locally()
 * ```
 *
 * Queries a paginable list of {@link Amity.Category} objects from cache
 *
 * @param query The query parameters
 * @returns categories
 *
 * @category category API
 */
queryCategories.locally = (
  query: Parameters<typeof queryCategories>[0],
): Amity.Cached<Amity.Paged<Amity.Category, Amity.Page>> | undefined => {
  const client = getActiveClient();
  client.log('category/queryCategories.locally', query);

  if (!client.cache) return;

  const { page = { limit: 10 }, ...params } = query ?? {};

  const queryKey = ['category', 'query', { ...params, options: { ...page } } as Amity.Serializable];
  const { data, cachedAt } =
    pullFromCache<{ categories: Pick<Amity.Category, 'categoryId'>[] } & Amity.Pagination>(
      queryKey,
    ) ?? {};

  if (!data?.categories.length) return;

  const categories: Amity.Category[] = data.categories
    .map(categoryId => pullFromCache<Amity.Category>(['category', 'get', categoryId])!)
    .filter(Boolean)
    .map(({ data }) => data);

  const prevPage = toPage(data?.paging.previous);
  const nextPage = toPage(data?.paging.next);

  return categories.length === data?.categories?.length
    ? { data: categories, cachedAt, prevPage, nextPage }
    : undefined;
};
