import { withUsers } from '~/group/utils/withUser';
import { getChannelMarkers } from '~/marker/api/getChannelMarkers';

import { getChannelUnreadCount } from './getChannelUnreadCount';

export const MARKER_INCLUDED_CHANNEL_TYPE = ['broadcast', 'conversation', 'community'];
export const isUnreadCountSupport = ({ type }: Pick<Amity.RawChannel, 'type'>) =>
  MARKER_INCLUDED_CHANNEL_TYPE.includes(type);

export function convertFromRaw(
  channel: Amity.RawChannel,
  marker?: Amity.ChannelMarker,
): Amity.Channel {
  return {
    ...channel,
    defaultSubChannelId: channel._id,
    isUnreadCountSupport: isUnreadCountSupport(channel),
    unreadCount: getChannelUnreadCount(channel, marker),
  };
}

export const prepareChannelPayload = async (
  rawPayload: Amity.ChannelPayload,
): Promise<Amity.ProcessedChannelPayload> => {
  // make a fetch marker to prepare it for merging with the raw channel payload.
  let markers: Amity.ChannelMarker[] = [];

  const markerIds = rawPayload.channels
    // filter channel by type. Only conversation, community and broadcast type are included.
    .filter(isUnreadCountSupport)
    .map(({ channelId }) => channelId);

  if (markerIds.length > 0)
    // from the spec, allow marker fetch to fail
    try {
      ({ data: markers } = await getChannelMarkers(markerIds));
    } catch (e) {
      // empty block
    }

  // attach marker to channel
  const channels = rawPayload.channels.map(channel => {
    const marker = markers?.find(({ entityId }) => entityId === channel.channelId);

    return convertFromRaw(channel, marker);
  });

  // user marker to channel users
  const channelUsers: Amity.Membership<'channel'>[] = withUsers(rawPayload.channelUsers);

  return {
    ...rawPayload,
    channels,
    channelUsers,
  };
};
