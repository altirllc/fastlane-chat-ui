import { pullFromCache } from '~/cache/api/pullFromCache';
import { getActiveUser } from '~/client/api/activeUser';
import { getResolver } from '~/core/model';

const getCachedMarker = (entityId: string) => {
  const key = {
    entityId,
    userId: getActiveUser()._id,
  };

  return pullFromCache<Amity.ChannelMarker>([
    'channelMarker',
    'get',
    getResolver('channelMarker')(key),
  ])?.data;
};

export const getChannelUnreadCount = (channel: Amity.RawChannel, marker?: Amity.ChannelMarker) => {
  if (marker?.isDeleted) {
    // NOTE: This is a temporary solution to handle the channel marker when the user is forced to
    // leave the channel because currently backend can't handle this, so every time a user is banned
    // from a channel or the channel is deleted the channel's unread count will reset to zero
    return 0;
  }

  return marker?.unreadCount ?? getCachedMarker(channel.channelId)?.unreadCount ?? 0;
};
