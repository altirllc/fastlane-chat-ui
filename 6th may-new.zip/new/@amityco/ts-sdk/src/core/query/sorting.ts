// Note:
// this file should contain a suite of sorting utilities to help the
// local version of the query functions.

type SortingFunc<T = Record<string, unknown>> = (a: T, b: T) => number;

/**
 * Alphabetic sorting of objects having a displayName
 */
export const sortByDisplayName: SortingFunc<{ displayName: string }> = (
  { displayName: a },
  { displayName: b },
) => {
  if (a === b) return 0;
  return a < b ? -1 : 1;
};

/**
 * Alphabetic sorting of objects having a name
 */
export const sortByName: SortingFunc<{ name: string }> = ({ name: a }, { name: b }) => {
  if (a === b) return 0;
  return a < b ? -1 : 1;
};

/**
 * Sorting a collection by their apparition order (oldest first)
 */
export const sortByChannelSegment: SortingFunc<{ channelSegment: number }> = (
  { channelSegment: a },
  { channelSegment: b },
) => a - b;

/**
 * Sorting a collection by their apparition order (oldest first)
 */
export const sortBySegmentNumber: SortingFunc<{ segmentNumber: number }> = (
  { segmentNumber: a },
  { segmentNumber: b },
) => a - b;

/**
 * Sorting a collection by its oldest items
 */
export const sortByFirstCreated: SortingFunc<{ createdAt: Date | number | string }> = (
  { createdAt: a },
  { createdAt: b },
) => new Date(a).valueOf() - new Date(b).valueOf();

/**
 * Sorting a collection by its newest items
 */
export const sortByLastCreated: SortingFunc<{ createdAt: Date | number | string }> = (
  { createdAt: a },
  { createdAt: b },
) => new Date(b).valueOf() - new Date(a).valueOf();

/**
 * Sorting a collection by the items with most recent activity
 */
export const sortByLastActivity: SortingFunc<{ lastActivity: Date | number | string }> = (
  { lastActivity: a },
  { lastActivity: b },
) => new Date(b).valueOf() - new Date(a).valueOf();
