import { getResolver } from '~/core/model';
import { pullFromCache } from '~/cache/api';
// Note:
// this file should contain a suite of filtering utilities to help the
// local version of the query functions.

/**
 * Filter a given collection with strict equality against a param
 *
 * @param collection the collection to filter
 * @param key the key of the collection's items to challenge
 * @param value the expected value
 * @returns a filtered collection with items only matching the criteria
 *
 * @hidden
 */
export const filterByPropEquality = <T = Record<string, unknown>>(
  collection: T[],
  key: keyof T,
  value: any,
) => (value !== undefined ? collection.filter(item => item[key] === value) : collection);

export const filterByPropInclusion = <T = Record<string, unknown>>(
  collection: T[],
  key: keyof T,
  value: any[] | undefined,
) => (value !== undefined ? collection.filter(item => value.includes(item[key])) : collection);

/**
 * Filter a channel collection by membership of the userId
 *
 * @param collection the channel collection to filter
 * @param membership the membership to be filtered by
 * @param userId user id to be filtered by
 * @returns a filtered collection with items only matching the criteria
 *
 * @hidden
 */
export const filterByChannelMembership = (
  collection: Amity.Channel[],
  membership: Amity.ChannelLiveCollection['membership'],
  userId: Amity.Membership<'channel'>['userId'],
): Amity.Channel[] => {
  if (membership === 'all') {
    return collection;
  }

  return collection.filter(c => {
    // get resolver for the channel by user
    const channelUserCacheKey = getResolver('channelUsers')({
      channelId: c.channelId,
      userId,
    });

    const channelUser = pullFromCache<Amity.Membership<'channel'>>([
      'channelUsers',
      'get',
      channelUserCacheKey,
    ])?.data;

    if (membership === 'member') {
      return channelUser && channelUser.membership !== 'none';
    }

    // only membership value remainging is 'notMember'
    return !channelUser || channelUser.membership === 'none';
  });
};

/**
 * Filter a channel collection by membership of the userId
 *
 * @param collection the channel collection to filter
 * @param feedType to be filtered by
 * @returns a filtered collection with items only matching the criteria
 *
 * @hidden
 */
export const filterByFeedType = <T extends Amity.Post>(
  collection: T[],
  feedType: Amity.Feed['feedType'],
): T[] => {
  /*
   * It is possible that the targetId & feedId are the same for most of the posts
   * But since cache is in-memory, i've avoided memoizing, to avoid premature
   * optimization. Can be revisited if performance issues arise
   */
  return collection.filter(({ targetId, feedId }) => {
    const feed = pullFromCache<Amity.Feed>([
      'feed',
      'get',
      getResolver('feed')({ targetId, feedId }),
    ])?.data!;

    return feed && feed.feedType === feedType;
  });
};

/**
 * Filter a community collection by membership of the userId
 *
 * @param collection the community to filter
 * @param membership the membership to be filtered by
 * @param userId user id to be filtered by
 * @returns a filtered collection with items only matching the criteria
 *
 * @hidden
 */
export const filterByCommunityMembership = <T extends Amity.Community>(
  collection: T[],
  membership: Amity.CommunityLiveCollection['membership'],
  userId: Amity.Membership<'community'>['userId'],
): T[] => {
  if (membership === 'all') {
    return collection;
  }

  return collection.filter(c => {
    // get resolver for the community by user
    const communityUserCacheKey = getResolver('communityUsers')({
      communityId: c.communityId,
      userId,
    });

    const communityUser = pullFromCache<Amity.Membership<'community'>>([
      'communityUsers',
      'get',
      communityUserCacheKey,
    ])?.data;

    if (membership === 'member') {
      return communityUser && communityUser.communityMembership === 'member';
    }

    // only membership value remainging is 'notMember'
    return !communityUser || communityUser.communityMembership !== 'none';
  });
};

/**
 * Filter a post collection by dataType
 *
 * @param collection the post to filter
 * @param dataTypes of the post to be filtered by
 * @returns a filtered collection with items only matching the criteria
 *
 * @hidden
 */
export const filterByPostDataTypes = <T extends Amity.Post>(
  collection: T[],
  dataTypes: Amity.PostLiveCollection['dataTypes'],
): T[] => {
  const filteredPosts: T[] = [];

  collection.forEach(c => {
    /*
     * A text post with no children is just a text post
     */
    if (c.dataType === 'text' && !c.children.length) return;

    if (c.children.length) {
      const childPost = pullFromCache<Amity.Post>(['post', 'get', c.children[0]])?.data;

      if (childPost && dataTypes?.includes(childPost?.dataType)) {
        // @ts-ignore
        filteredPosts.push(childPost);
      }

      return;
    }

    if (dataTypes?.includes(c.dataType)) filteredPosts.push(c);
  });

  return filteredPosts;
};

/**
 * Filter a collection by search term
 * Check if userId matches first if not filter by displayName
 *
 * @param collection to be filtered
 * @param searchTerm to filter collection by
 * @returns a filtered collection with items only matching the search term
 *
 * @hidden
 */
export const filterBySearchTerm = <T extends { userId: Amity.User['userId']; user?: Amity.User }>(
  collection: T[],
  searchTerm: string,
): T[] => {
  const containsMatcher = new RegExp(searchTerm);

  return collection.filter(m => {
    if (m.userId.match(containsMatcher)) return true;

    return m.user && m.user.displayName?.match(containsMatcher);
  });
};
