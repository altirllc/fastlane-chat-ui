import { getActiveClient } from '~/client/api/activeClient';
import { ASCError } from '~/core/errors';
import { proxyMqttEvents } from '~/core/events';
import { getActiveUser } from '~/client/api/activeUser';

export enum SubscriptionLevels {
  COMMUNITY = 'community',
  POST = 'post',
  COMMENT = 'comment',
  POST_AND_COMMENT = 'post_and_comment',
  USER = 'user',
}

const getCommunityUserTopic = (
  path: Amity.Subscribable['path'],
  level?: SubscriptionLevels,
): string => {
  switch (level) {
    case 'post':
      return `${path}/post/+`;
    case 'comment':
      return `${path}/post/+/comment/+`;
    case 'post_and_comment':
      return `${path}/post/#`;
    default:
      return path;
  }
};

const getNetworkId = (user: { path: string }): string => user.path.split('/user/')[0];

export const getCommunityTopic = (
  { path }: Amity.Subscribable,
  level: Exclude<SubscriptionLevels, SubscriptionLevels.USER> = SubscriptionLevels.COMMUNITY,
): string => getCommunityUserTopic(path, level);

export const getUserTopic = (
  { path }: Amity.Subscribable,
  level: Exclude<SubscriptionLevels, SubscriptionLevels.COMMUNITY> = SubscriptionLevels.USER,
): string =>
  getCommunityUserTopic(
    level === SubscriptionLevels.USER ? path : path.replace(/^(\w*)/, '$1/social'),
    level,
  );

export const getPostTopic = (
  { path }: Amity.Subscribable,
  level: SubscriptionLevels.POST | SubscriptionLevels.COMMENT = SubscriptionLevels.POST,
): string => {
  switch (level) {
    case 'comment':
      return `${path}/comment/+`;
    default:
      return path;
  }
};

export const getCommentTopic = ({ path }: Amity.Subscribable): string => {
  return path;
};

export const getMyFollowersTopic = (): string => {
  const user = getActiveUser();

  return `${getNetworkId(user)}/membership/${user._id}/+/+`;
};

export const getMyFollowingsTopic = (): string => {
  const user = getActiveUser();

  return `${getNetworkId(user)}/membership/+/${user._id}/+`;
};

export const getChannelTopic = (channel: Amity.Subscribable): string => `${channel.path}/#`;

export const getSubChannelTopic = (subChannel: Amity.Subscribable): string =>
  `${subChannel.path}/#`;

export const getMessageTopic = (message: Amity.Subscribable): string => message.path;

export const getMarkedMessageTopic = ({
  channelId,
  subChannelId,
}: Pick<Amity.SubChannel, 'channelId' | 'subChannelId'>): string => {
  const user = getActiveUser();

  return `${getNetworkId(user)}/marker/channel/${channelId}/message/${subChannelId}`;
};

/**
 * @hidden
 *
 * Create a topic to subscribe to network level events like 'user is deleted from the network'
 */
export const getNetworkTopic = (): string => {
  return getNetworkId(getActiveUser());
};

/**
 * @hidden
 *
 * Create a topic to subscribe to channel events for 'conversation', 'community' channel
 */
export const getSmartFeedChannelTopic = (): string => {
  const user = getActiveUser();

  return `${getNetworkId(user)}/smartfeed/${user._id}/channels`;
};

/**
 * @hidden
 *
 * Create a topic to subscribe to sub channel events for 'conversation', 'community' channel
 */
export const getSmartFeedSubChannelTopic = (): string => {
  const user = getActiveUser();

  return `${getNetworkId(user)}/smartfeed/${user._id}/messagefeeds`;
};

/**
 * @hidden
 *
 * Create a topic to subscribe to message events for 'conversation', 'community' channel
 */
export const getSmartFeedMessageTopic = (): string => {
  const user = getActiveUser();

  return `${getNetworkId(user)}/smartfeed/${user._id}/messages`;
};

let mqttAccessToken: string;
let mqttUserId: string;

export function subscribeTopic(
  topic: string,
  callback?: Amity.Listener<ASCError | void>,
): Amity.Unsubscriber {
  const { mqtt, emitter, token } = getActiveClient();
  const accessToken = token?.accessToken ?? '';

  const user = getActiveUser();

  if (mqttAccessToken !== accessToken || mqttUserId !== user._id) {
    mqttAccessToken = accessToken!;
    mqttUserId = user._id!;

    mqtt.connect({ accessToken: mqttAccessToken, userId: mqttUserId });
    proxyMqttEvents(mqtt, emitter);
  }

  return mqtt.subscribe(topic, callback);
}
