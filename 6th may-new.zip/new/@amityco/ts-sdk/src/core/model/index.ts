export * from './idResolvers';
export * from './identifyModel';

/**
 * A map of v3 response keys to a store name.
 * @hidden
 */
export const PAYLOAD2MODEL: Record<string, Amity.Domain> = {
  users: 'user',
  files: 'file',
  roles: 'role',

  channels: 'channel',
  messageFeeds: 'subChannel',
  channelUsers: 'channelUsers',
  messages: 'message',

  userEntityMarkers: 'channelMarker',
  userFeedMarkers: 'subChannelMarker',
  contentMarkers: 'messageMarker',
  feedMarkers: 'feedMarker',
  userMarkers: 'userMarker',

  communities: 'community',
  categories: 'category',
  communityUsers: 'communityUsers',
  posts: 'post',
  postChildren: 'post',
  comments: 'comment',
  polls: 'poll',
  reactions: 'reaction',

  videoStreamings: 'stream',

  follows: 'follow',
  followCounts: 'followCount',

  feeds: 'feed',
};

/** hidden */
export const hasUpdates = <T extends Amity.Model>(prevData: T, nextData: T): boolean => {
  if ('updatedAt' in prevData && 'updatedAt' in nextData) {
    return new Date(prevData.updatedAt!) < new Date(nextData.updatedAt!);
  }

  /*
   * hasUpdates is used to identify the latest object among many. If the object
   * does not extend ${Amity.UpdatedAt}, then there is no way to differentiate.
   * So it is considered by default that the object hasUpdates
   */
  return true;
};

/** hidden */
export function getFutureDate(date: string | undefined = new Date().toISOString()): string {
  return new Date(new Date(date).getTime() + 1).toISOString();
}

/** hidden */
export function getPastDate(date: string | undefined = new Date().toISOString()): string {
  return new Date(new Date(date).getTime() - 1).toISOString();
}
