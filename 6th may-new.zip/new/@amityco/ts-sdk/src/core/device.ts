// TODO: find a way to uniquely identify the device
// import { getStorage } from './storage'
import { safeProcess } from '~/utils/env';
import { VERSION } from '~/version';

/** @hidden */
export const getDeviceId = () => {
  // here maybe put some auto detection of the device id based on if it's react or not?
  // anyhow we let consumer branch out if they want, but it doesn't mean we shouldn't try to be nice
  // and do things automatically
  // https://www.npmjs.com/package/react-native-device-info#getuniqueid
  // how to make sure that the react native package will not be included when build is for web
  return `ascWebSdk#${Math.random().toString(16)}`;
};

/** @hidden */
export const getDeviceModel = () => {
  if (safeProcess.versions?.node) return safeProcess.versions.node;

  if (navigator)
    return `${navigator.product.toLowerCase()}#${navigator.userAgent ?? 'unknown_agent'}`;

  return 'unknown_model';
};

/** @hidden */
export const getDeviceInfo = (): Amity.Device['deviceInfo'] => {
  const model = getDeviceModel();

  return {
    // TODO: replace with: kind: process.versions ? 'node' : 'web', when backend has fixed this
    kind: 'web',
    model,
    sdkVersion: VERSION,
  };
};
