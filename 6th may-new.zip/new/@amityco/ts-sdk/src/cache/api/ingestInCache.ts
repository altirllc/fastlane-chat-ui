import { PAYLOAD2MODEL, getResolver } from '~/core/model';

import { upsertInCache } from './upsertInCache';

/**
 * Ingest a payload (v3) into the cache
 *
 * @param payload a "backend v3" payload object
 * @param options caching options like cachedAt or offline
 *
 * @category Cache
 * @hidden
 */
export const ingestInCache = (
  payload: Record<keyof typeof PAYLOAD2MODEL, Amity.Model[]> = {},
  options?: Amity.CacheOptions,
) => {
  Object.entries(payload).forEach(([key, models]) => {
    const type = PAYLOAD2MODEL[key];
    if (!type) return;

    const resolver = getResolver(type);
    if (!resolver) return;

    models.forEach(model => {
      upsertInCache([type, 'get', resolver(model)], model, options);
    });
  });
};
