export const ANALYTIC_CACHE_KEY = ['analytic', 'normal-priority'];
export const HIGH_PRIORITY_ANALYTIC_CACHE_KEY = ['analytic', 'high-priority'];
