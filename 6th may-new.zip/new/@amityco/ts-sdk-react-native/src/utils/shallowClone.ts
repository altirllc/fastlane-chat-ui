/**
 * ```js
 * import { shallowClone } from '~/utils/shallowClone'
 * const newObj = shallowClone(obj)
 * ```
 *
 * Clone an object with same prototype and properties
 *
 * @param obj the object to clone
 * @returns new object with same prototype and properties
 *
 * @category utility
 * @private
 */
export function shallowClone(obj: any) {
  const clone = Object.create(Object.getPrototypeOf(obj));
  const descriptors = Object.getOwnPropertyDescriptors(obj);
  Object.defineProperties(clone, descriptors);
  return clone;
}
