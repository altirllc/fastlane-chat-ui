export enum StoryType {
  image = 'image',
  video = 'video',
}
