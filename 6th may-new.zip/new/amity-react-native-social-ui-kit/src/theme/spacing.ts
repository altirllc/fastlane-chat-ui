export const SCREEN_PADDING = 24;
export const TAB_BAR_HEIGHT = 60;
