import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  searchBar: {
    height: 40,
    backgroundColor: '#EBECEF',
    borderWidth: 0,
    paddingHorizontal: 10,
    marginVertical: 10,
    marginHorizontal: 10,
  },
});
