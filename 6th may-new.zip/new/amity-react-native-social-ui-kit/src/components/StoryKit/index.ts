import Story from './src/Story';

export * from './src/interfaces';

export const AmityStory = Story;

export default AmityStory;
