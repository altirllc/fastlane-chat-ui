import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  text: {
    // fontFamily: 'SFProText-Regular',
    color: 'black',
  },
});

export default styles;
