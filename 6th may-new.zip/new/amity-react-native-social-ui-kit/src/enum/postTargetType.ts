export enum PostTargetType {
  user = 'user',
  community = 'community',
  content = 'content',
}
