export enum PrivacyState {
  private = 'private',
  public = 'public',
}
