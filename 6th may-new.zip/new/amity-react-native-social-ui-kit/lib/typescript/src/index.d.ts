import AmityUiKitProvider from './providers/amity-ui-kit-provider';
import AmityUiKitSocial from './routes/SocialNavigator';
import { AmityStoryTabComponent, AmityCreateStoryPage, AmityDraftStoryPage, AmityViewStoryPage } from './v4';
import { AmityStoryTabComponentEnum } from './v4/PublicApi/types';
export declare function multiply(a: number, b: number): Promise<number>;
export { AmityUiKitProvider, AmityUiKitSocial, AmityStoryTabComponent, AmityStoryTabComponentEnum, AmityCreateStoryPage, AmityDraftStoryPage, AmityViewStoryPage, };
//# sourceMappingURL=index.d.ts.map