export declare const isModerator: (userRoles?: string[]) => boolean;
export declare const isAdmin: (userRoles?: string[]) => boolean;
export declare const isCommunityModerator: ({ userId, communityId, }: {
    userId: string;
    communityId: string;
}) => Promise<boolean>;
//# sourceMappingURL=permission.d.ts.map