export declare const msToString: (duration: number) => string;
//# sourceMappingURL=timeUtil.d.ts.map