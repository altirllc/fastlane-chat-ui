import { StoryType } from '../v4/enum';
export declare const checkURLValidation: (url: string) => boolean;
export declare const getMediaTypeFromUrl: (url: string) => StoryType;
//# sourceMappingURL=urlUtil.d.ts.map