import { IPost } from '../components/Social/PostList';
export declare const amityPostsFormatter: (posts: Amity.Post<any>[]) => Promise<IPost[]>;
//# sourceMappingURL=postDataFormatter.d.ts.map