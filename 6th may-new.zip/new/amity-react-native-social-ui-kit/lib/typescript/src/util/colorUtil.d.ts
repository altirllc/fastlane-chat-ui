export declare const validateConfigColor: (color: string) => string;
//# sourceMappingURL=colorUtil.d.ts.map