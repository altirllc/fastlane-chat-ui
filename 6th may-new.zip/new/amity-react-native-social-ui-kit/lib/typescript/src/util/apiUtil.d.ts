export declare const getAvatarURL: (apiRegion: string, fileId: string) => string;
//# sourceMappingURL=apiUtil.d.ts.map