export declare const isMember: (userRoles?: string[]) => boolean;
export declare const isModerator: (userRoles?: string[]) => boolean;
export declare const isAdmin: (userRoles?: string[]) => boolean;
//# sourceMappingURL=communityMemberRolesUtil.d.ts.map