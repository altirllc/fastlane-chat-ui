import * as React from 'react';
import { DefaultTheme, type MD3Theme } from 'react-native-paper';
import { IConfigRaw } from '../v4/types/config.interface';
export type CusTomTheme = typeof DefaultTheme;
export interface IAmityUIkitProvider {
    userId: string;
    displayName?: string;
    apiKey: string;
    apiRegion?: string;
    apiEndpoint?: string;
    children: any;
    authToken?: string;
    configs?: IConfigRaw;
}
interface CustomColors {
    primary?: string;
    secondary?: string;
    background?: string;
    base?: string;
    baseShade1?: string;
    baseShade2?: string;
    baseShade3?: string;
    baseShade4?: string;
    alert?: string;
}
export interface MyMD3Theme extends MD3Theme {
    colors: MD3Theme['colors'] & CustomColors;
}
export default function AmityUiKitProvider({ userId, displayName, apiKey, apiRegion, apiEndpoint, children, authToken, configs, }: IAmityUIkitProvider): React.JSX.Element;
export {};
//# sourceMappingURL=amity-ui-kit-provider.d.ts.map