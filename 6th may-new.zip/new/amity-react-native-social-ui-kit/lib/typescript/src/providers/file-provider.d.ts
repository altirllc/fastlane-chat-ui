export declare function uploadFile(filePath: string, perCentCallback?: (percent: number) => void): Promise<Amity.File<any>[]>;
export declare function uploadImageFile(filePath: string, perCentCallback?: (percent: number) => void): Promise<Amity.File<any>[]>;
export declare function uploadVideoFile(filePath: string, perCentCallback?: (percent: number) => void): Promise<Amity.File<any>[]>;
export declare function deleteAmityFile(fileId: string): Promise<{
    success: boolean;
}>;
//# sourceMappingURL=file-provider.d.ts.map