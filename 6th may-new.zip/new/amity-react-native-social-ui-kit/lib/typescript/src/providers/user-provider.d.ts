import type { UserGroup } from '../types/user.interface';
export declare function groupUsers(users: Amity.User[]): UserGroup[];
export declare function reportUser(userId: string): Promise<boolean>;
export declare function getAmityUser(userId: string): Promise<any>;
//# sourceMappingURL=user-provider.d.ts.map