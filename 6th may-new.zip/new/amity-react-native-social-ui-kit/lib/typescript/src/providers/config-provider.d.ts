import React, { ReactNode } from 'react';
import { IConfigRaw, IUIKitConfig } from '~/v4/types/config.interface';
interface IConfigProviderProps {
    children: ReactNode;
    configs: IConfigRaw;
}
export declare const ConfigContext: React.Context<IUIKitConfig>;
export declare const ConfigProvider: ({ children, configs }: IConfigProviderProps) => React.JSX.Element;
export {};
//# sourceMappingURL=config-provider.d.ts.map