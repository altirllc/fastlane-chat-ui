export declare enum SessionState {
    established = "established",
    notLoggedIn = "notLoggedIn",
    establishing = "establishing",
    tokenExpired = "tokenExpired",
    terminated = "terminated"
}
//# sourceMappingURL=sessionState.d.ts.map