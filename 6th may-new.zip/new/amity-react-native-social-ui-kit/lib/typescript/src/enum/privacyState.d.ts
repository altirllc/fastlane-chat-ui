export declare enum PrivacyState {
    private = "private",
    public = "public"
}
//# sourceMappingURL=privacyState.d.ts.map