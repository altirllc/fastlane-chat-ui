export declare enum PostTargetType {
    user = "user",
    community = "community",
    content = "content"
}
//# sourceMappingURL=postTargetType.d.ts.map