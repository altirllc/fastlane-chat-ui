export interface IUIKitConfig {
    globalTheme: Record<string, any>;
    excludes: string[];
    getConfig: (id: string) => any;
}
//# sourceMappingURL=config.interface.d.ts.map