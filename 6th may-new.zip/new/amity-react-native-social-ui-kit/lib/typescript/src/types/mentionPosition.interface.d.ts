export interface IMentionPosition {
    index: number;
    type: string;
    userId: string;
    length: number;
    displayName?: string;
}
//# sourceMappingURL=mentionPosition.interface.d.ts.map