export declare const useStyles: () => {
    btnWrap: {
        padding: number;
    };
    dotIcon: {
        width: number;
        height: number;
    };
};
//# sourceMappingURL=style.d.ts.map