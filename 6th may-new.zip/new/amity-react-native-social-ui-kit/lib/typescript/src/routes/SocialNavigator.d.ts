import * as React from 'react';
export default function SocialNavigator({ hideCompleteProfileCard, }: {
    hideCompleteProfileCard: boolean;
}): React.JSX.Element;
//# sourceMappingURL=SocialNavigator.d.ts.map