import { IColors } from '../theme/colors';
export type TTheme = {
    colors: IColors;
    isDark: boolean;
};
export declare const useCustomTheme: () => TTheme;
//# sourceMappingURL=useCustomTheme.d.ts.map