import { PostRepository } from '@amityco/ts-sdk-react-native';
type ElementOf<T> = T extends Array<infer U> ? U : never;
type TUseGallery = Partial<Pick<Parameters<typeof PostRepository.getPosts>[0], 'targetId' | 'targetType' | 'limit'>> & {
    dataType: ElementOf<Parameters<typeof PostRepository.getPosts>[0]['dataTypes']>;
};
export declare const useGallery: ({ targetId, targetType, dataType, limit, }: TUseGallery) => {
    mediaFiles: any[];
    getNextPage: () => void;
};
export {};
//# sourceMappingURL=useGallery.d.ts.map