interface IUIKitConfig {
    globalTheme: Record<string, any>;
    excludes: string[];
    getConfig: (key: string) => any;
}
declare const useConfig: () => IUIKitConfig;
export default useConfig;
//# sourceMappingURL=useConfig.d.ts.map