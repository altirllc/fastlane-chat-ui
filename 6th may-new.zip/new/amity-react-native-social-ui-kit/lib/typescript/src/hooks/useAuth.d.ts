import type { AuthContextInterface } from '../types/auth.interface';
declare const useAuth: () => AuthContextInterface;
export default useAuth;
//# sourceMappingURL=useAuth.d.ts.map