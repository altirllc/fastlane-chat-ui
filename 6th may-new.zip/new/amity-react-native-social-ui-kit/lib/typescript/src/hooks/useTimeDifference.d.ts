export declare const useTimeDifference: (timestamp: string, isStory?: boolean) => string;
//# sourceMappingURL=useTimeDifference.d.ts.map