import { ImageSizeSubset } from '../enum/imageSizeState';
interface useFileProps {
    fileId: string;
    imageSize?: ImageSizeSubset;
}
declare const useFile: ({ fileId, imageSize, }: useFileProps) => string;
export default useFile;
//# sourceMappingURL=useFile.d.ts.map