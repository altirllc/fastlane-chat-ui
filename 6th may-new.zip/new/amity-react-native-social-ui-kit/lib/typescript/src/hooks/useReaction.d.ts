export declare const useReaction: ({ referenceId, referenceType, }: {
    referenceId: string;
    referenceType: Amity.ReactableType;
}) => {
    loading: boolean;
    reactions: {
        like: number;
        all: number;
    };
    reactors: Amity.User[];
};
//# sourceMappingURL=useReaction.d.ts.map