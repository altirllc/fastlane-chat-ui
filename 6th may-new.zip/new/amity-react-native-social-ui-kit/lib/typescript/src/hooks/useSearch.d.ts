import { ISearchItem } from '../components/SearchItem';
export type TSearchItem = Amity.User & ISearchItem & Amity.Membership<'community'> & {
    name: string;
    id: string;
};
declare const useSearch: (searchText?: string, privateCommunityId?: string) => {
    searchResult: TSearchItem[];
    getNextPage: () => void;
};
export default useSearch;
//# sourceMappingURL=useSearch.d.ts.map