interface IUserStory {
    targetId: string;
    targetType: Amity.StoryTargetType;
}
export declare const useStory: () => {
    handleReaction: ({ targetId, reactionName, isLiked, }: {
        targetId: string;
        reactionName: string;
        isLiked: boolean;
    }) => Promise<void>;
    getStories: ({ targetId, targetType }: IUserStory) => void;
    stories: Amity.Story[];
    loading: boolean;
    onNextPage: () => void;
};
export {};
//# sourceMappingURL=useStory.d.ts.map