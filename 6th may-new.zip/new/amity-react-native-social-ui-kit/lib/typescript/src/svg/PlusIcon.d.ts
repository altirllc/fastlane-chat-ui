import React from 'react';
export declare const PlusIcon: ({ color }: {
    color?: string;
}) => React.JSX.Element;
//# sourceMappingURL=PlusIcon.d.ts.map