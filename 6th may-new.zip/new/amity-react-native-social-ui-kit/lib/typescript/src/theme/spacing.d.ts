export declare const SCREEN_PADDING = 24;
export declare const TAB_BAR_HEIGHT = 60;
//# sourceMappingURL=spacing.d.ts.map