import { ColorValue } from 'react-native/types';
interface IGetShadowProps {
    offset?: number;
    radius?: number;
    opacity?: number;
    color?: ColorValue;
    noElevation?: boolean;
}
export declare const getShadowProps: (props?: IGetShadowProps) => {
    shadowColor: ColorValue;
    shadowOffset: {
        width: number;
        height: number;
    };
    shadowOpacity: number;
    shadowRadius: number;
    elevation: number;
};
export {};
//# sourceMappingURL=helpers.d.ts.map