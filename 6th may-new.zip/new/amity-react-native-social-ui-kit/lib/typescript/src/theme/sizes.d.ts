export declare const sizes: ISizes;
interface ISizes {
    readonly [index: string]: number;
    sm: number;
    sm2: number;
    sm3: number;
    md: number;
    md1: number;
    md2: number;
    md3: number;
    md4: number;
    lg: number;
    lg2: number;
    lg3: number;
    lg4: number;
    lg5: number;
    xl: number;
    xl2: number;
    xl3: number;
    xl4: number;
    xl5: number;
    xl6: number;
    xl7: number;
}
export {};
//# sourceMappingURL=sizes.d.ts.map