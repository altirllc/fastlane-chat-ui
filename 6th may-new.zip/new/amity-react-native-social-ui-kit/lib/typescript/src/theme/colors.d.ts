import { ColorValue } from 'react-native';
export declare const colorsLight: IColors;
export declare const colorsDark: IColors;
interface IPalette {
    readonly [index: number]: ColorValue;
    main: ColorValue;
}
export interface IColors {
    readonly [index: string]: IPalette | ColorValue;
    transparent: ColorValue;
    primary: IPalette;
    secondary: IPalette;
    success: IPalette;
    info: IPalette;
    error: IPalette;
    warning: IPalette;
    headerBackground: ColorValue;
    background: ColorValue;
    blueGray: ColorValue;
    cardMain: ColorValue;
}
export {};
//# sourceMappingURL=colors.d.ts.map