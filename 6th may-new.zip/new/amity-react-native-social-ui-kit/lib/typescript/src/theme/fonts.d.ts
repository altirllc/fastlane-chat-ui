export declare const fontFamilies: IFontFamilies;
interface IFontFamilies {
    readonly [index: string]: IFontFamily;
    thin: IFontFamily;
    thinItalic: IFontFamily;
    extraLight: IFontFamily;
    extraLightItalic: IFontFamily;
    light: IFontFamily;
    lightItalic: IFontFamily;
    regular: IFontFamily;
    regularItalic: IFontFamily;
    medium: IFontFamily;
    mediumItalic: IFontFamily;
    semiBold: IFontFamily;
    semiBoldItalic: IFontFamily;
    bold: IFontFamily;
    boldItalic: IFontFamily;
    black: IFontFamily;
    blackItalic: IFontFamily;
    extraBold: IFontFamily;
    extraBoldItalic: IFontFamily;
}
interface IFontFamily {
    fontFamily: string;
    fontWeight: 'normal' | 'bold' | '100' | '200' | '300' | '400' | '500' | '600' | '700' | '800' | '900' | undefined;
}
export {};
//# sourceMappingURL=fonts.d.ts.map